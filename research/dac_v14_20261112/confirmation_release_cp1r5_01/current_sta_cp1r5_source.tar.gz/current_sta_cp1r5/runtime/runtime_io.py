#!/usr/bin/env python3
"""Candidate no-ptrace timing receipts; not yet validated for formal study."""
import os
import json
from pathlib import Path
import signal
import subprocess
import threading
import time

from runtime_common import PYTHON, sha256, utc, write_json
from runtime_dependencies import bind_runtime
from runtime_metrics import parse_metrics
from process_tree_observer import ProcessTreeObserver

BASE = None
ADDRESS_SPACE_BYTES = 64*1024**3
GUARD = Path(__file__).with_name('seccomp_thread_guard').resolve()
GUARD_VALIDATION = Path(__file__).with_name('guard_manifest.json').resolve()
_cache = {}
_lock = threading.Lock()


def identity(path):
    s = Path(path).stat()
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)


def frozen_hash(path, expected=None):
    """Hash once per supervisor; refuse any later change to a shared input."""
    path = str(Path(path).resolve())
    with _lock:
        before = identity(path)
        if path in _cache:
            previous, digest = _cache[path]
            if before != previous: raise RuntimeError(f'Frozen input changed: {path}')
        else:
            digest = sha256(path)
            if before != identity(path): raise RuntimeError(f'Input changed during hashing: {path}')
            _cache[path] = (before, digest)
        if expected is not None and expected != digest: raise RuntimeError(f'Input hash mismatch: {path}')
        return dict(sha256=digest, stat_identity=before)


def run(name, command, *, frozen=(), private_inputs=(), environment=None, timeout=1800, tags=None):
    """Run one private process group and preserve failures without retries."""
    assert BASE is not None, 'Caller must supply an explicit output directory'
    directory = Path(BASE).resolve()/'runs'/name
    directory.mkdir(parents=True, exist_ok=True)
    receipt = directory/'manifest.json'
    if receipt.exists(): raise FileExistsError(receipt)
    command = list(map(str, command))
    shared = {str(Path(p).resolve()): frozen_hash(p) for p in frozen}
    # Bind the preregistered resolved dynamic dependencies as well as binaries.
    dependency_file = BASE/'runtime_dependency_binding.json'
    dependency_binding = json.loads(dependency_file.read_text())
    assert Path(command[0]).resolve()==Path(dependency_binding['binary']), 'Executable differs from runtime binding'
    shared[str(Path(command[0]).resolve())]=frozen_hash(command[0],dependency_binding['binary_sha256'])
    if dependency_binding.get('missing'):
        raise RuntimeError('Runtime dependency binding contains unresolved libraries')
    shared[str(dependency_file.resolve())] = frozen_hash(dependency_file)
    for path, expected in dependency_binding['sha256'].items():
        shared[path] = frozen_hash(path, expected)
    mutable = {str(Path(p).resolve()): sha256(p) for p in private_inputs}
    env = os.environ.copy()
    for key in list(env):
        if key.startswith('VPR_H3D_'): del env[key]
    for key in ('LD_PRELOAD','LD_AUDIT','LD_LIBRARY_PATH'):
        env.pop(key,None)
    env['PATH'] = str(PYTHON.parent)+os.pathsep+env['PATH']
    overrides = dict(OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    overrides.update(environment or {}); env.update(overrides)
    data = dict(name=name, command=command, cwd=str(directory), shared_inputs=shared,
        private_input_sha256=mutable, environment=overrides, timeout_seconds=timeout,
        tags=tags or {}, start_utc=utc(), status='starting', supervisor_pid=os.getpid(),
        runner_sha256=frozen_hash(__file__)['sha256'],
        execution_limit=dict(address_space_bytes=ADDRESS_SPACE_BYTES, core_dump_bytes=0,
            enforcement='/usr/bin/prlimit --as=soft:hard --core=0:0, inherited by children'))
    validation=json.loads(GUARD_VALIDATION.read_text())
    assert validation['format']=='portable_guard_artifact_v1'
    expected_guard=validation['artifact_sha256']['seccomp_thread_guard']
    data['thread_enforcement'] = dict(method='seccomp_guard_no_ptrace',
        guard=frozen_hash(GUARD,expected_guard),validation=frozen_hash(GUARD_VALIDATION),
        qualification='Linux x86-64 seccomp filter denies clone3 and kills a caller of clone with CLONE_THREAD; inherited by exec and descendants. BPF overhead and behavior change require workload validation.')
    shared[str(GUARD)]=data['thread_enforcement']['guard']
    shared[str(GUARD_VALIDATION)]=data['thread_enforcement']['validation']
    for wrapper in ('/usr/bin/time','/usr/bin/prlimit'):
        shared[wrapper]=frozen_hash(wrapper)
    launch_command=['/usr/bin/time','-v','-o',str(directory/'time.txt'),
        '/usr/bin/prlimit',f'--as={ADDRESS_SPACE_BYTES}:{ADDRESS_SPACE_BYTES}',
        '--core=0:0','--',str(GUARD),*command]
    data['launch_command']=launch_command
    data['environment_sanitization']='Remove inherited VPR_H3D_*, LD_PRELOAD, LD_AUDIT and LD_LIBRARY_PATH; explicit overrides and bridge-local settings remain.'
    write_json(receipt, data)
    started = time.monotonic()
    with (directory/'stdout.log').open('x') as output:
        try:
            proc = subprocess.Popen(launch_command,
                cwd=directory, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        except OSError as error:
            data.update(status='launch_failed', error=str(error), finish_utc=utc())
            write_json(receipt, data); return data
        data.update(status='running', process_group_id=proc.pid); write_json(receipt, data)
        observer = ProcessTreeObserver(proc.pid)
        observer.start()
        try:
            code = proc.wait(timeout=timeout); status = 'completed' if code == 0 else 'failed'
        except subprocess.TimeoutExpired:
            os.killpg(proc.pid, signal.SIGTERM)
            try: proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL); proc.wait()
            code, status = proc.returncode, 'timeout'
        finally:
            thread_observation = observer.stop()
    data['process_tree_observation'] = thread_observation
    data['execution_status'] = status
    timing_file=directory/'time.txt'
    killed_by_sigsys=timing_file.exists() and 'Command terminated by signal 31' in timing_file.read_text(errors='replace')
    data['thread_enforcement']['top_level_sigsys_observed']=killed_by_sigsys
    if thread_observation['violation_observed'] or killed_by_sigsys:
        status = 'thread_constraint_violated'
    elif thread_observation['samples'] == 0 or not thread_observation['processes']:
        status = 'thread_observation_missing'
    data.update(status=status, returncode=code, finish_utc=utc(), wall_seconds=time.monotonic()-started,
                metrics=parse_metrics((directory/'stdout.log').read_text(errors='replace')))
    changed = [p for p, h in shared.items() if identity(p) != tuple(h['stat_identity'])]
    if changed: data.update(status='input_integrity_failed', changed_inputs=changed)
    data['outputs'] = {p.name: dict(sha256=sha256(p), bytes=p.stat().st_size)
        for p in [directory/f for f in ['packed.net', 'placed.place', 'routed.route', 'stdout.log', 'time.txt']] if p.exists()}
    write_json(receipt, data)
    print(name, data['status'], flush=True)
    return data


def seal_inputs(output):
    """Full final rehash makes cached checks explicit and independently reviewable."""
    with _lock: entries = dict(_cache)
    results = {}
    for path, (previous, expected) in entries.items():
        actual = sha256(path)
        results[path] = dict(sha256=actual, stat_identity=identity(path), passed=actual == expected and identity(path) == previous)
    write_json(output, dict(utc=utc(), inputs=results, passed=all(x['passed'] for x in results.values())))
    if not all(x['passed'] for x in results.values()): raise RuntimeError('Frozen input finalization failed')


def configure(output,binary):
    """Bind this exact executable's current dynamic libraries before native work."""
    global BASE
    assert BASE is None, 'One runtime instance belongs to one batch'
    BASE=Path(output).resolve();BASE.mkdir(parents=True,exist_ok=False)
    bind_runtime(binary,BASE/'runtime_dependency_binding.json')
    return BASE
